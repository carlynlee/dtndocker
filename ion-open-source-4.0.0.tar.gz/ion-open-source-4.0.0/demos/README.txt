The sample code in this directory demonstrates some features of ION.  To run
one of the demos, cd into its top-level directory and type "./rundemo".

The bss-unicast demo has been removed; this demo is now performed by running
the "xterm-dotest" script in ../tests/bssp.
