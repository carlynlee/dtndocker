NM Tools   {#tools}
=======

NM is currently packaged with the following tools:
- CAmpPython

# CAmpPython
This tool is used to automatically generate C source and header files for ADMs using the input JSON files. 

This tool can be found under nm/contrib/CAmpPython.  See the included README file for details.
