====================================
Dummy external Date provider example
====================================

This example implements a dummy, minimal external Date provider.
