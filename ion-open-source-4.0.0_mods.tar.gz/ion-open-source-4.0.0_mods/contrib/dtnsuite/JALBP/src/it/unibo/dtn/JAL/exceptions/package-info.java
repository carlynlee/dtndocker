/** 
 * Exception throwed by JAL library.
 * <p>
 * This package contains all the Exception throwable by JALBP functions.<br>
 * 
 * @author Andrea Bisacchi
 * @version 1.0
 *
 */
package it.unibo.dtn.JAL.exceptions;