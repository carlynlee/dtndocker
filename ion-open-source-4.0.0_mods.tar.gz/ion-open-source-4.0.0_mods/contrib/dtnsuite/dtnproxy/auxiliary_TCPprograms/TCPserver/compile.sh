#to compile TCPclient
gcc main.c -o tcpserver
#to install
sudo cp tcpserver /usr/local/bin
sudo ldconfig


