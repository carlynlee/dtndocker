#to compile TCPclient
gcc main.c -o tcpclient
#to install
sudo cp tcpclient /usr/local/bin
sudo ldconfig


