#!/bin/bash

echo `whereis tcpcli`
echo `whereis tcpclo`
echo `whereis ionadmin`
